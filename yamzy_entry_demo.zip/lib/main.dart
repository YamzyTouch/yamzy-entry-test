
import 'package:flutter/material.dart';

void main() {
  runApp(YamzyApp());
}

class YamzyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yamzy TouchBox',
      home: EntryScreen(),
    );
  }
}

class EntryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[100],
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => BusinessFormScreen())
                );
              },
              child: Text('İş Sahibi'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text('Yeni Üyelik'),
            ),
          ],
        ),
      ),
    );
  }
}

class BusinessFormScreen extends StatelessWidget {
  final _companyController = TextEditingController();
  final _titleController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Firma Bilgileri')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _companyController,
              decoration: InputDecoration(labelText: 'Şirket Adı'),
            ),
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Unvan'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Simülasyon: Telefon ile kaydol
              },
              child: Text('Telefon ile Kaydol'),
            ),
          ],
        ),
      ),
    );
  }
}
